# @Author : CyIce
# @Time : 2024/6/25 10:13

import os
import numpy as np
import torch
from .arg_parser import args_parsing
from .preprocess.preprocessing import preprocessing
from .factor_net.factor_grn import get_factor_grn
from .factor_net.permutation_test import diff_exp_test
from .factor_net.pathway_identify import pathway_predict, pw_args_parsing
from .train import train_pyg_gcn, seed_everything, create_network


def main():
    args = args_parsing().parse_args()
    seed_everything(42)

    is_train = True if args.train == "true" else False
    activation = torch.nn.Sigmoid() if args.activation == 'sigmoid' else torch.nn.ReLU()
    device = torch.device("cuda") if args.device == "gpu" else torch.device("cpu")
    args.train = True if args.train == "true" else False
    encoder_layer = list(map(int, args.encoder_layer.split(',')))
    decoder_layer = list(map(int, args.decoder_layer.split(',')))

    # Create the output folder if it does not exist.
    if not os.path.exists(f"./out/{args.name}"):
        os.makedirs(f"./out/{args.name}")

    exp, edges = preprocessing(args.name, args.exp_path, args.net_path, args.mean, args.var, args.norm_type)
    print(len(exp), len(edges))
    genes = [row[0] for row in exp]
    feats = np.array([row[1:] for row in exp])
    feats = torch.tensor(feats).squeeze()
    num_stages = feats.shape[1]
    # create the mapping beween symbol and index
    symbol2idx = {row[0]: index for index, row in enumerate(exp)}
    idx2symbol = {idx: symbol for symbol, idx in symbol2idx.items()}
    # convert symbol to index
    edges = [[symbol2idx[edge[0]], symbol2idx[edge[1]]] for edge in edges]
    # create the dgl graph
    num_nodes = len(genes)
    g = create_network(edges, num_nodes)
    print(f"TF-Gene network: {g}")
    # training DTGN model
    hidden_feats = train_pyg_gcn(args.name, genes, feats, edges, activation, args.lr, args.wd, args.epochs, device,
                                 encoder_layer, decoder_layer, is_train)
    # Constructing the dynamic TF-Gene network for each stage.
    print("Constructing dynamic TGNs...")
    get_factor_grn(args.name, feats, edges, idx2symbol, num_stages, args.threshold)

    # Using permutation test to test the significance of the TFs.
    # print("Permutation test...")
    # diff_exp_test(args.name, num_stages, args.permutation_times)



def tf_prediction():
    args = args_parsing().parse_args()
    diff_exp_test(args.name, args.num_stages, args.permutation_times)


def pw_prediction():

    args = pw_args_parsing().parse_args()
    dataset = args.dataset
    pathway_path = args.pathway_path
    nums_stage = args.num_stages
    name = args.name
    permutation_times = args.permutation_times
    threshold = args.threshold
    pathway_predict(dataset, name, pathway_path, nums_stage, threshold, permutation_times)
